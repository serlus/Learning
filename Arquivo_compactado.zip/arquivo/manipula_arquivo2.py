import os
from os import path
import shutil
from shutil import make_archive
from zipfile import ZipFile


def criar_zip_modo_1():
    shutil.make_archive("Arquivo_compactado", "zip", "/home/serlus/repositorios/Learning/estudos/linkedin")


criar_zip_modo_1()